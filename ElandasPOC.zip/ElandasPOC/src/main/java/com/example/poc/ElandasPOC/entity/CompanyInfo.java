package com.example.poc.ElandasPOC.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "test2")
public class CompanyInfo {

    @Getter
    @Setter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "serial")
    private  int id;
    @Getter
    @Setter
    private String name ;
    @Getter
    @Setter
    private int age ;
    @Getter
    @Setter
    private String address ;
    @Getter
    @Setter
    private int salary ;
    @Getter
    @Setter
    private String startTime;
    @Getter
    @Setter
    private String endTime;
}
