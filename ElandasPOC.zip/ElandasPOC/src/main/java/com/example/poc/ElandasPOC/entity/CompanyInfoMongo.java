package com.example.poc.ElandasPOC.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

import javax.persistence.Id;
@Component
@Document(collection = "test2")
public class CompanyInfoMongo {
    @Id
    @Getter
    @Setter
    private  int id;
    @Getter
    @Setter
    private String name ;
    @Getter
    @Setter
    private int age ;
    @Getter
    @Setter
    private String address ;
    @Getter
    @Setter
    private int salary ;
    @Getter
    @Setter
    private String startTime;
    @Getter
    @Setter
    private String endTime;
}
