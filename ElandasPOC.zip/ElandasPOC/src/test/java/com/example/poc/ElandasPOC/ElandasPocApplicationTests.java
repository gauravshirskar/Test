package com.example.poc.ElandasPOC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElandasPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
